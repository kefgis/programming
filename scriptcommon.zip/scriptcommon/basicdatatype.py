x = 2
y = 2.0
type(x)
type(y)

inputData = 'trees.shp'
inputData
inputData = “trees.shp”
inputData
print(inputData)

output = 'a b c d e f \
    g h i'
print(output)

fieldName = 'COVER'
fieldName[0] = 'D'

A = 'COVER'
print(A)
A = A.replace('C','D')
print(A)

fieldName = 'COVER'
fieldName[1:3]
fieldName[:3]
fieldName[1:]
inputData = 'trees.shp'
baseName = inputData[:-4] # Remove the file extension.
baseName


A = 'ethiopianroads'

A[-4:-2]