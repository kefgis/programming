







# This function adds two numbers
def KEFadd(x, y):
    return x + y


A =20000
B =300
C = KEFadd(A, B)
print(f'The sum of {A} and {B} is {C}.')
print('The sum of ' + str(A) + ' and ' + str(B) + ' is ' + str(C) + '')









# This function subtracts two numbers
def subtract(x, y):
    return x - y

# This function multiplies two numbers
def multiply(x, y):
    return x * y

# This function divides two numbers
def divide(x, y):
    return x / y
A = 100
B =200
C = add(A,B)
print(f'The sum of {A} and {B} is {C}.')