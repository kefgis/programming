# Example 2: Add Two Numbers With User Input
# Store input numbers
num1 = input('Enter first number: ')
num2 = input('Enter second number: ')

# Add two numbers
sum = float(num1) + float(num2)

# Display the sum
## Option 1
print('The sum of, num1 , 'and', num2, 'is' , sum, '.'

## Option 2
print('The sum of {0} and {1} is {2}'.format(num1, num2, sum))