# Example: For positive numbers
# Python Program to calculate the square root

#Note: change this value for a different result
num =  8

# To take the input from the user
#num = float(input('Enter a number: '))

-num_sqrt = num ** 0.5
print('The square root of {0} is {1}'.format(num ,num_sqrt))