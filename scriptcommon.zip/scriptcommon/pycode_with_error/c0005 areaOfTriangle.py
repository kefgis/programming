# Python Program to find the area of triangle

a = 5
b = 6
c = 7

# Uncomment below to take inputs from the user
# a = float(input('Enter first side: '))
# b = float(input('Enter second side: '))
# c = float(input('Enter third side: '))

# calculate the semi-perimeter
s = (a + b + c) / 2

# calculate the area
area = (s*(s-a)*(s-b)*(s-c)) ** 0.5

# round the area to two decimal place.
area = round(area,3
             
# To display the area use option 1
print('The area is', area, '.')

# To display the area use option 2
print('The area is {0}.'.format(area))