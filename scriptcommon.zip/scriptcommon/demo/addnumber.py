A = 1
B =2
C = A + B
print('The sum of A and B is ' + str(C))