'''
Create a nested list in Python that includes 
 - UTM coordinates (x, y), 
 - elevation (z), and 
 -  cover types with some example imagery data. 

Here's a simple example:
'''

# Example UTM coordinates (x, y), elevation (z), and land cover types
utm_data = [
    [500000, 4649776, 100, 'Forest'],
    [500100, 4649786, 105, 'Water'],
    [500200, 4649796, 110, 'Urban'],
    [500300, 4649806, 115, 'Agriculture']
]

# Print the nested list
for i in utm_data:
    print(i[0], i[1], i[2], i[3]) 
   # print(f"UTM Coordinates: ({data[0]}, {data[1]}), Elevation: {data[2]}m, Land Cover: {data[3]}")

'''
In this example:
- Each inner list represents a data point with 
    - UTM coordinates (x, y), 
    - elevation (z), and
    - land cover type.
- The `utm_data` list contains multiple such data points.
- You can replace the coordinates, elevation, and land cover types with your actual data. 
- This structure is useful for organizing and processing geospatial data in Python.
'''
