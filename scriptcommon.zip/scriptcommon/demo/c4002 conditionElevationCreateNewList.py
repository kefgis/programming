'''
A Python exercise that checks if an elevation is 
below 4500 meters and 
above -149 meters in Ethiopia. 
This exercise builds on basic Python concepts like conditional statements and user input.
'''
# Function to check if an elevation is within the acceptable range
def check_elevation(elevation):
    return -149 < elevation < 4500

# Sample elevations to test
sample_elevations = [3000, 5000, -200, 4500, -100, 0, 4000]

# Create a new list to store valid elevations
valid_elevations = []

# Iterate over each elevation in the sample_elevations list
for elevation in sample_elevations:
    # Check if the current elevation is within the acceptable range
    if check_elevation(elevation):
        # If it is, add it to the valid_elevations list
        valid_elevations.append(elevation)

# Print the list of valid elevations
print("Valid elevations within the range:", valid_elevations)

'''
In this extended version:
- Function Definition: The check_elevation function checks if an elevation is 
 -- between -149 and 4500 meters.

Sample Elevations: We have a list of sample elevations to test.
New List Creation: We create an empty list valid_elevations to store the elevations that are within the acceptable range.
Iteration: We use a for loop to iterate over each elevation in the sample_elevations list.
Condition Check: Inside the loop, we use the check_elevation function to check if the current elevation is within the range.
Appending to List: If the elevation is valid, we add it to the valid_elevations list using the append method.
Output: Finally, we print the valid_elevations list.
This step-by-step approach should make it easier for new users to understand how the list comprehension works and how to achieve the same result using a more explicit method. If you have any more questions or need further clarification, feel free to ask
'''