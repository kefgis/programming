#Exercise 1: 

'''
# Extend the GISPoint Class to Include a Method that Calculates the Distance to Another Point
We will use the Haversine formula to calculate the distance between two points on the Earth's surface.
'''

import math

class GISPoint:
    def __init__(self, latitude, longitude):
        self.latitude = latitude
        self.longitude = longitude

    def display_coordinates(self):
        print(f"Latitude: {self.latitude}, Longitude: {self.longitude}")

    def distance_to(self, other_point):
        # Radius of the Earth in kilometers
        R = 6371.0

        lat1 = math.radians(self.latitude)
        lon1 = math.radians(self.longitude)
        lat2 = math.radians(other_point.latitude)
        lon2 = math.radians(other_point.longitude)

        dlat = lat2 - lat1
        dlon = lon2 - lon1

        a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        distance = R * c
        return distance

# Example usage
point1 = GISPoint(9.145, 40.489)
point2 = GISPoint(7.946, 39.789)

print(f"Distance: {point1.distance_to(point2)} km")

# Calaulate the ditance bteween Addis ababa and Hawassa:
'''
Here are the coordinates for both cities:

Addis Ababa:
    Latitude: 9.0250° N
    Longitude: 38.7469° E1

Hawassa:
    Latitude: 7.0621° N
    Longitude: 38.4764° E2
'''
