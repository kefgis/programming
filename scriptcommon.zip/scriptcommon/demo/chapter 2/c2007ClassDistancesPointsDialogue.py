# Demonstration: Expanding the class
'''
Let's see into how we can expand our simple class to include more attributes and methods, and integrate it into a real-world GIS application. We'll demonstrate this with a CSV file that contains point pairs with attributes like place names, coordinates (x, y), and elevation.
'''
# 1. Expanding the Class
'''
First, let's expand the Point class to include additional attributes and methods for calculating distances:
'''

import math

class GISPoint:
    def __init__(self, name, x, y, elevation):
        self.name = name
        self.x = x
        self.y = y
        self.elevation = elevation

    def horizontal_distance(self, other_point):
        return math.sqrt((self.x - other_point.x) ** 2 + (self.y - other_point.y) ** 2)

    def vertical_distance(self, other_point):
        return abs(self.elevation - other_point.elevation)

    def surface_distance(self, other_point):
        horizontal_dist = self.horizontal_distance(other_point)
        vertical_dist = self.vertical_distance(other_point)
        return math.sqrt(horizontal_dist ** 2 + vertical_dist ** 2)

    def __repr__(self):
        return f"GISPoint({self.name}: {self.x}, {self.y}, {self.elevation})"
# 2. Parsing CSV File and Calculating Distances
'''
Let's assume our CSV file (points.csv) is structured as follows:
place1name,x1,y1,elevation1,place2name,x2,y2,elevation2
LocationA,10,20,300,LocationB,30,40,350
We can read this CSV file, create GISPoint objects, and calculate the distances:
'''

import csv
from tkinter import filedialog, Tk

class GISPoint:
    def __init__(self, lat, lon, elevation=0):
        self.lat = lat
        self.lon = lon
        self.elevation = elevation

    def distance_to(self, other_point):
        R = 6371.0  # Radius of the Earth in kilometers

        lat1 = math.radians(self.lat)
        lon1 = math.radians(self.lon)
        lat2 = math.radians(other_point.lat)
        lon2 = math.radians(other_point.lon)

        dlat = lat2 - lat1
        dlon = lon2 - lon1

        a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        distance = R * c

        return distance

    def display_coordinates(self):
        print(f"GISPoint({self.lat}, {self.lon}, {self.elevation})")

    def __repr__(self):
        return f"GISPoint({self.lat}, {self.lon}, {self.elevation})"

def read_points_from_csv(file_path):
    point_pairs = []
    with open(file_path, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip header
        for row in reader:
            point1 = GISPoint(float(row[1]), float(row[2]), float(row[3]))  # Correcting indices
            point2 = GISPoint(float(row[5]), float(row[6]), float(row[7]))  # Correcting indices
            point_pairs.append((point1, point2))
    return point_pairs

def select_file():
    root = Tk()
    root.withdraw()  # Hide the root window
    file_path = filedialog.askopenfilename(title="Select CSV file", filetypes=[("CSV Files", "*.csv")])
    root.destroy()  # Close the tkinter instance
    return file_path

def calculate_distances(point_pairs):
    for point1, point2 in point_pairs:
        horizontal_dist = point1.distance_to(point2)
        print(f"Distance between {point1} and {point2}: {horizontal_dist:.2f} km")
        print("-" * 40)

# Main function
if __name__ == "__main__":
    file_path = select_file()
    if file_path:
        point_pairs = read_points_from_csv(file_path)
        calculate_distances(point_pairs)
    else:
        print("No file selected.")
