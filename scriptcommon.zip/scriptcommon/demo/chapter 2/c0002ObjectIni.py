# Object Initialization and Self
''' The __init__ method initializes an object's attributes. 
The self keyword represents the instance of the class.
'''
# python
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

point1 = Point(10, 20)
print(f"X: {point1.x}, Y: {point1.y}")
