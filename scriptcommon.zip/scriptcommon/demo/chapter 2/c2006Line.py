#Exercise 2
'''
Create a GISLine Class that Represents a Line Made Up of Multiple GISPoint Objects

'''
import math

class GISPoint:
    def __init__(self, lat, lon, elevation=0):
        self.lat = lat
        self.lon = lon
        self.elevation = elevation

    def distance_to(self, other_point):
        R = 6371.0  # Radius of the Earth in kilometers

        lat1 = math.radians(self.lat)
        lon1 = math.radians(self.lon)
        lat2 = math.radians(other_point.lat)
        lon2 = math.radians(other_point.lon)

        dlat = lat2 - lat1
        dlon = lon2 - lon1

        a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        distance = R * c

        return distance

    def display_coordinates(self):
        print(f"GISPoint({self.lat}, {self.lon}, {self.elevation})")

    def __repr__(self):
        return f"GISPoint({self.lat}, {self.lon}, {self.elevation})"

class GISLine:
    def __init__(self):
        self.points = []

    def add_point(self, point):
        self.points.append(point)

    def total_length(self):
        if len(self.points) < 2:
            return 0
        total_distance = 0
        for i in range(len(self.points) - 1):
            total_distance += self.points[i].distance_to(self.points[i + 1])
        return total_distance

    def display_line(self):
        for point in self.points:
            point.display_coordinates()

# Example usage
line = GISLine()
line.add_point(GISPoint(9.145, 40.489))
line.add_point(GISPoint(7.946, 39.789))
line.add_point(GISPoint(8.980, 38.757))
line.display_line()
print(f"Total Length: {line.total_length()} km")
