# python code: demonstration of class
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point({self.x}, {self.y})"

# Defining Object and Attributes
'''O#bjects are instances of classes. 
Attributes are the data stored in objects.'''
# python
# Create an instance of Point
point1 = Point(10, 20)
print(point1)
