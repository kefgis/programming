# Using Classes in Another Python Module
""" 
You can define classes in one module and use them in another. Here's an example:
In geometry.py 
"""
# python
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def distance_to(self, other_point):
        return ((self.x - other_point.x)**2 + (self.y - other_point.y)**2)**0.5
