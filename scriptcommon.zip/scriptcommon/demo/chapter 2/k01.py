# python
class Kef:
    def __init__(self, x, y):
        self.x = x  # 'self.x' refers to the instance's x attribute
        self.y = y  # 'self.y' refers to the instance's y attribute

    def display(self):
        return f"Point({self.x}, {self.y})"

# Creating an object of class Point
point1 = Kef(10, 20)
print(point1.display())  # Output: Point(10, 20)
