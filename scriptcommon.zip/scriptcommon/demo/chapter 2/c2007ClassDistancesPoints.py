# Demonstration: Expanding the class
'''
Let's see into how we can expand our simple class to include more attributes and methods, and integrate it into a real-world GIS application. We'll demonstrate this with a CSV file that contains point pairs with attributes like place names, coordinates (x, y), and elevation.
'''
# 1. Expanding the Class
'''
First, let's expand the Point class to include additional attributes and methods for calculating distances:
'''

import math

class GISPoint:
    def __init__(self, name, x, y, elevation):
        self.name = name
        self.x = x
        self.y = y
        self.elevation = elevation

    def horizontal_distance(self, other_point):
        return math.sqrt((self.x - other_point.x) ** 2 + (self.y - other_point.y) ** 2)

    def vertical_distance(self, other_point):
        return abs(self.elevation - other_point.elevation)

    def surface_distance(self, other_point):
        horizontal_dist = self.horizontal_distance(other_point)
        vertical_dist = self.vertical_distance(other_point)
        return math.sqrt(horizontal_dist ** 2 + vertical_dist ** 2)

    def __repr__(self):
        return f"GISPoint({self.name}: {self.x}, {self.y}, {self.elevation})"
# 2. Parsing CSV File and Calculating Distances
'''
Let's assume our CSV file (points.csv) is structured as follows:
place1name,x1,y1,elevation1,place2name,x2,y2,elevation2
LocationA,10,20,300,LocationB,30,40,350
We can read this CSV file, create GISPoint objects, and calculate the distances:
'''

# python
import csv

# Function to read CSV file and create point pairs
def read_points_from_csv(file_path):
    point_pairs = []
    with open(file_path, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip header
        for row in reader:
            point1 = GISPoint(row[0], float(row[1]), float(row[2]), float(row[3]))
            point2 = GISPoint(row[4], float(row[5]), float(row[6]), float(row[7]))
            point_pairs.append((point1, point2))
    return point_pairs

# Function to calculate distances
def calculate_distances(point_pairs):
    for point1, point2 in point_pairs:
        horizontal_dist = point1.horizontal_distance(point2)
        vertical_dist = point1.vertical_distance(point2)
        surface_dist = point1.surface_distance(point2)
        print(f"Distances between {point1.name} and {point2.name}:")
        print(f"Horizontal Distance: {horizontal_dist}")
        print(f"Vertical Distance: {vertical_dist}")
        print(f"Surface Distance: {surface_dist}")
        print("-" * 40)

# Example usage
d = r'C:\geodb2017kefs\scriptcommon\data\points.csv'
point_pairs = read_points_from_csv(d)
calculate_distances(point_pairs)
