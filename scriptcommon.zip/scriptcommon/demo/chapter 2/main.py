# In main.py:
# python
from geometry import Point

point1 = Point(10, 20)
point2 = Point(30, 40)

print(f"Distance kkkkkkkkkk: {point1.distance_to(point2)}")
