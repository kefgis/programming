#Integrating GIS Applications
'''
Let's integrate these concepts into a simple GIS application 
that manipulates geographic data using Python.
WE assume, you have the geometry.py in the same folder as this file
'''
# python
from geometry import Point
class GISPoint(Point):
    def __init__(self, x, y, name):
        super().__init__(x, y)
        self.name = name

    def __repr__(self):
        return f"GISPoint({self.name}: {self.x}, {self.y})"

# Create GIS Points
point1 = GISPoint(10, 20, "LocationA")
point2 = GISPoint(30, 40, "LocationB")

# Calculate the distance between points
print(f"Distance between {point1.name} and {point2.name}: {point1.distance_to(point2)}")
