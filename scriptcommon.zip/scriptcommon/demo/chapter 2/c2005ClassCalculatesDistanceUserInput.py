
#  Calculates the Distance to Another Point
'''
We will use the Haversine formula to calculate the distance between two points on the Earth's surface.
Ask the user to enter the places name and coordinates
'''
'''
A code that will ask the user for the coordinates of the two towns:
'''

import math

class GISPoint:
    def __init__(self, name, lat, lon, elevation=0):
        self.name = name
        self.lat = lat
        self.lon = lon
        self.elevation = elevation

    def haversine_distance(self, other_point):
        # Radius of Earth in kilometers
        R = 6371.0

        # Coordinates in radians
        lat1 = math.radians(self.lat)
        lon1 = math.radians(self.lon)
        lat2 = math.radians(other_point.lat)
        lon2 = math.radians(other_point.lon)

        # Differences in coordinates
        dlat = lat2 - lat1
        dlon = lon2 - lon1

        # Haversine formula
        a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        # Distance in kilometers
        distance = R * c

        return distance

    def __repr__(self):
        return f"GISPoint({self.name}: {self.lat}, {self.lon}, {self.elevation})"

# Prompting user to enter coordinates
town1_name = input("Enter the name of the first town: ")
town1_lat = float(input("Enter the latitude of the first town: "))
town1_lon = float(input("Enter the longitude of the first town: "))

town2_name = input("Enter the name of the second town: ")
town2_lat = float(input("Enter the latitude of the second town: "))
town2_lon = float(input("Enter the longitude of the second town: "))

# Creating GISPoint objects
town1 = GISPoint(town1_name, town1_lat, town1_lon)
town2 = GISPoint(town2_name, town2_lat, town2_lon)

# Calculating the distance
distance = town1.haversine_distance(town2)
print(f"Distance between {town1.name} and {town2.name}: {distance:.2f} km")
# How to Use
    ### Run the Program: When you run the program, it will prompt you to enter the names and coordinates of the two towns.
    ### Input Coordinates: Enter the latitude and longitude for each town when prompted.
    ### Calculate Distance: The program will calculate and display the distance between the two towns using the haversine formula.
    ### This way, users can input the geographic coordinates of any two towns or points of interest to calculate the distance between them.