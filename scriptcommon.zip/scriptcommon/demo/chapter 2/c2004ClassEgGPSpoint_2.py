# Exercise: 
'''
Add a method to the GISPoint class to display the coordinates of the point.
'''

class GISPoint:
    def __init__(self, latitude, longitude):
        self.latitude = latitude
        self.longitude = longitude
    
    def display_coordinates(self):
        print(f"Latitude: {self.latitude}, Longitude: {self.longitude}")

point1 = GISPoint(9.145, 40.489)
point1.display_coordinates()
