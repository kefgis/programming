'''
To allow the user to enter multiple points, calculate the distances in sequence, and save them all in one CSV file with a single "Save Results" button, we can adjust the code as follows:

Add List Storage for Entries: Use a list to store each calculation until the user decides to save all results at once.
Add Save Button: Allow the user to save all calculated distances to a CSV file in one go.
Clear Entry Fields After Each Calculation: Reset the input fields so the user can enter the next set of points easily.
Here is the modified code:

'''

import tkinter as tk
from tkinter import messagebox, filedialog
import math
import csv
import os

# Initialize list to store entries
entries = []
csv_file_path = None

def calculate_distance():
    try:
        x1 = float(entry_x1.get())
        y1 = float(entry_y1.get())
        x2 = float(entry_x2.get())
        y2 = float(entry_y2.get())
        
        # Calculate distance
        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        messagebox.showinfo("Distance", f"The distance is {distance:.2f}")
        
        # Store the data in the entries list
        entries.append((x1, y1, x2, y2, distance))
        
        # Clear entry fields
        entry_x1.delete(0, tk.END)
        entry_y1.delete(0, tk.END)
        entry_x2.delete(0, tk.END)
        entry_y2.delete(0, tk.END)
    
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers")

def save_results():
    global csv_file_path
    
    # Prompt user to select save location if not already chosen
    if not csv_file_path:
        csv_file_path = get_save_location()
        if not csv_file_path:  # If the user cancels, exit the function
            return
    
    # Save all entries to the CSV file
    with open(csv_file_path, mode='a', newline='') as file:
        writer = csv.writer(file)
        
        # Write header if the file is empty
        if os.stat(csv_file_path).st_size == 0:
            writer.writerow(["nr", "x1", "y1", "x2", "y2", "distance"])
        
        # Write all entries
        for i, (x1, y1, x2, y2, distance) in enumerate(entries, start=1):
            writer.writerow([i, x1, y1, x2, y2, distance])
    
    # Clear the entries list after saving
    entries.clear()
    messagebox.showinfo("Save Results", "All results have been saved successfully!")

def get_save_location():
    """Prompt the user to select a folder and enter a file name."""
    file_path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        title="Save File As"
    )
    return file_path

# Initialize window
root = tk.Tk()
root.title("Distance Calculator with Batch CSV Export")
root.geometry("300x300")

# Menu bar
menu_bar = tk.Menu(root)
root.config(menu=menu_bar)
file_menu = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="Exit", command=root.quit)

# Labels and Entry fields
label_x1 = tk.Label(root, text="X1:")
label_x1.grid(row=0, column=0, padx=5, pady=5)
entry_x1 = tk.Entry(root)
entry_x1.grid(row=0, column=1, padx=5, pady=5)

label_y1 = tk.Label(root, text="Y1:")
label_y1.grid(row=1, column=0, padx=5, pady=5)
entry_y1 = tk.Entry(root)
entry_y1.grid(row=1, column=1, padx=5, pady=5)

label_x2 = tk.Label(root, text="X2:")
label_x2.grid(row=2, column=0, padx=5, pady=5)
entry_x2 = tk.Entry(root)
entry_x2.grid(row=2, column=1, padx=5, pady=5)

label_y2 = tk.Label(root, text="Y2:")
label_y2.grid(row=3, column=0, padx=5, pady=5)
entry_y2 = tk.Entry(root)
entry_y2.grid(row=3, column=1, padx=5, pady=5)

# Calculate Button
button_calculate = tk.Button(root, text="Calculate Distance", command=calculate_distance)
button_calculate.grid(row=4, column=0, columnspan=2, pady=10)

# Save Button
button_save = tk.Button(root, text="Save Results", command=save_results)
button_save.grid(row=5, column=0, columnspan=2, pady=10)

root.mainloop()

'''
Explanation of Modifications:
A ) Store Entries in a List: Each calculated distance, along with its coordinates, is stored in the entries list.
B) save_results Function: Saves all entries in entries to the specified CSV file in a single batch.
C) Separate Save Button: After the user enters and calculates distances for multiple points, they can save all results at once with the "Save Results" button.
'''