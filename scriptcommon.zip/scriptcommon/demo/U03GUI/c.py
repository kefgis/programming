'''
To limit the application to only work with UTM coordinate systems, we can add a conditional check to display an error message when the user selects "Geographic" and attempt to calculate the distance. Here’s how the modified code would look:

'''
import tkinter as tk
from tkinter import messagebox
import math

def calculate_distance():
    # Check if a UTM coordinate system is selected
    selected_system = coord_system_var.get()
    if selected_system == "Geographic":
        messagebox.showerror("Error", "Sorry, I can only work with UTM coordinate systems.")
        return
    elif selected_system == "Select Coordinate System":
        messagebox.showerror("Error", "Please select a UTM coordinate system.")
        return

    try:
        x1 = float(entry_x1.get())
        y1 = float(entry_y1.get())
        x2 = float(entry_x2.get())
        y2 = float(entry_y2.get())
        
        # Calculate distance
        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        messagebox.showinfo("Distance", f"The distance is {distance:.2f} (using {selected_system})")
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers")

# Initialize window
root = tk.Tk()
root.title("Distance Calculator with UTM Coordinate System")
root.geometry("300x250")

# Menu bar
menu_bar = tk.Menu(root)
root.config(menu=menu_bar)
file_menu = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="Exit", command=root.quit)

# Coordinate System Selection
coord_system_var = tk.StringVar(root)
coord_system_var.set("Select Coordinate System")  # Default value

label_coord_system = tk.Label(root, text="Coordinate System:")
label_coord_system.grid(row=0, column=0, padx=5, pady=5)

# Dropdown for UTM Zones and Geographic
coord_system_menu = tk.OptionMenu(root, coord_system_var, "UTM Zone 36", "UTM Zone 37", "UTM Zone 38", "Geographic")
coord_system_menu.grid(row=0, column=1, padx=5, pady=5)

# Labels and Entry fields
label_x1 = tk.Label(root, text="X1:")
label_x1.grid(row=1, column=0, padx=5, pady=5)
entry_x1 = tk.Entry(root)
entry_x1.grid(row=1, column=1, padx=5, pady=5)

label_y1 = tk.Label(root, text="Y1:")
label_y1.grid(row=2, column=0, padx=5, pady=5)
entry_y1 = tk.Entry(root)
entry_y1.grid(row=2, column=1, padx=5, pady=5)

label_x2 = tk.Label(root, text="X2:")
label_x2.grid(row=3, column=0, padx=5, pady=5)
entry_x2 = tk.Entry(root)
entry_x2.grid(row=3, column=1, padx=5, pady=5)

label_y2 = tk.Label(root, text="Y2:")
label_y2.grid(row=4, column=0, padx=5, pady=5)
entry_y2 = tk.Entry(root)
entry_y2.grid(row=4, column=1, padx=5, pady=5)

# Calculate Button
button_calculate = tk.Button(root, text="Calculate Distance", command=calculate_distance)
button_calculate.grid(row=5, column=0, columnspan=2, pady=10)

root.mainloop()

'''
Key Modifications:
1. Check for "Geographic" Selection: When the user selects "Geographic" as the coordinate system, the code now displays an error message saying, "Sorry, I can only work with UTM coordinate systems."
2. Validate Selection: If the user has not selected any coordinate system (or leaves the default), an error will prompt them to select a UTM coordinate system. 

This way, the GUI restricts the distance calculation functionality to UTM systems only.
'''
