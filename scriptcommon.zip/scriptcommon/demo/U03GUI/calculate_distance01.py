##ode for GIS Distance Calculator GUI
''''
This GUI application can be further developed by adding GIS-specific widgets and functionality, such as map visualization or integration with mapping libraries like `folium`.
'''

import tkinter as tk
from tkinter import messagebox
import math

def calculate_distance():
    try:
        x1 = float(entry_x1.get())
        y1 = float(entry_y1.get())
        x2 = float(entry_x2.get())
        y2 = float(entry_y2.get())
        
        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        messagebox.showinfo("Distance", f"The distance is {distance:.2f}")
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers")

# Initialize window
root = tk.Tk()
root.title("Distance Calculator")
root.geometry("300x200")

# Menu bar
menu_bar = tk.Menu(root)
root.config(menu=menu_bar)
file_menu = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="Exit", command=root.quit)

# Labels and Entry fields
label_x1 = tk.Label(root, text="X1:")
label_x1.grid(row=0, column=0, padx=5, pady=5)
entry_x1 = tk.Entry(root)
entry_x1.grid(row=0, column=1, padx=5, pady=5)

label_y1 = tk.Label(root, text="Y1:")
label_y1.grid(row=1, column=0, padx=5, pady=5)
entry_y1 = tk.Entry(root)
entry_y1.grid(row=1, column=1, padx=5, pady=5)

label_x2 = tk.Label(root, text="X2:")
label_x2.grid(row=2, column=0, padx=5, pady=5)
entry_x2 = tk.Entry(root)
entry_x2.grid(row=2, column=1, padx=5, pady=5)

label_y2 = tk.Label(root, text="Y2:")
label_y2.grid(row=3, column=0, padx=5, pady=5)
entry_y2 = tk.Entry(root)
entry_y2.grid(row=3, column=1, padx=5, pady=5)

# Calculate Button
button_calculate = tk.Button(root, text="Calculate Distance", command=calculate_distance)
button_calculate.grid(row=4, column=0, columnspan=2, pady=10)

root.mainloop()
