'''
To add the functionality for saving inputs along with the calculated distance into a CSV file, we will use Python's csv module. We will enhance the GUI by adding an option to choose a save location, specify a file name, and log each calculation.

Here iss how to do it:

A) File Dialog: Allow the user to choose a save location using tkinter.filedialog.
B) CSV Export: Save each calculation result to a CSV file with columns: nr, x1, y1, x2, y2, and distance.
'''
import tkinter as tk
from tkinter import messagebox, filedialog
import math
import csv
import os

# Initialize counter for entries
entry_counter = 1
csv_file_path = None

def calculate_distance():
    global entry_counter, csv_file_path
    
    try:
        x1 = float(entry_x1.get())
        y1 = float(entry_y1.get())
        x2 = float(entry_x2.get())
        y2 = float(entry_y2.get())
        
        # Calculate distance
        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        messagebox.showinfo("Distance", f"The distance is {distance:.2f}")
        
        # Check if CSV file path is set
        if not csv_file_path:
            csv_file_path = get_save_location()
            if not csv_file_path:  # If the user cancels, exit the function
                return
            
        # Append the data to the CSV file
        save_to_csv(entry_counter, x1, y1, x2, y2, distance)
        entry_counter += 1  # Increment the counter for the next entry
    
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers")

def get_save_location():
    """Prompt the user to select a folder and enter a file name."""
    file_path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        title="Save File As"
    )
    
    # Create a new file with headers if it doesn't already exist
    if file_path:
        if not os.path.exists(file_path):
            with open(file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["nr", "x1", "y1", "x2", "y2", "distance"])  # Write header row
        return file_path
    return None

def save_to_csv(nr, x1, y1, x2, y2, distance):
    """Save a row of data to the CSV file."""
    with open(csv_file_path, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([nr, x1, y1, x2, y2, distance])

# Initialize window
root = tk.Tk()
root.title("Distance Calculator with CSV Export")
root.geometry("300x250")

# Menu bar
menu_bar = tk.Menu(root)
root.config(menu=menu_bar)
file_menu = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="Exit", command=root.quit)

# Labels and Entry fields
label_x1 = tk.Label(root, text="X1:")
label_x1.grid(row=0, column=0, padx=5, pady=5)
entry_x1 = tk.Entry(root)
entry_x1.grid(row=0, column=1, padx=5, pady=5)

label_y1 = tk.Label(root, text="Y1:")
label_y1.grid(row=1, column=0, padx=5, pady=5)
entry_y1 = tk.Entry(root)
entry_y1.grid(row=1, column=1, padx=5, pady=5)

label_x2 = tk.Label(root, text="X2:")
label_x2.grid(row=2, column=0, padx=5, pady=5)
entry_x2 = tk.Entry(root)
entry_x2.grid(row=2, column=1, padx=5, pady=5)

label_y2 = tk.Label(root, text="Y2:")
label_y2.grid(row=3, column=0, padx=5, pady=5)
entry_y2 = tk.Entry(root)
entry_y2.grid(row=3, column=1, padx=5, pady=5)

# Calculate Button
button_calculate = tk.Button(root, text="Calculate Distance", command=calculate_distance)
button_calculate.grid(row=4, column=0, columnspan=2, pady=10)

root.mainloop()


'''
Explanation of Key Additions:
CSV File Path Selection:

The get_save_location() function prompts the user to select a location and name for the CSV file.
The CSV file is created if it does not already exist, and column headers (nr, x1, y1, x2, y2, distance) are added.
Saving Each Calculation:

The save_to_csv() function appends each calculation's result as a new row in the CSV file, with an entry number that increments automatically.
Error Handling:

If the user cancels file selection, the calculate_distance() function will stop without saving.
'''