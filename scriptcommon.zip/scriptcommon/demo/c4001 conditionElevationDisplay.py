'''
A Python exercise that checks if an elevation is 
below 4500 meters and 
above -149 meters in Ethiopia. 
This exercise builds on basic Python concepts like conditional statements and user input.
'''
# Function to check elevation
def check_elevation(elevation):
    if -149 < elevation < 4500:
        return "Elevation is within the acceptable range."
    else:
        return "Elevation is out of the acceptable range."

# Sample elevations to test
sample_elevations = [3000, 5000, -200, 4500, -100, 0, 4000]

# Check each sample elevation
for elevation in sample_elevations:
    result = check_elevation(elevation)
    print(f"Elevation: {elevation} meters - {result}")