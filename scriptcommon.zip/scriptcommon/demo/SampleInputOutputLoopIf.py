# Read from the input file, process data, and write to an output file

def read_file(file_path):
    with open(file_path, 'r') as file:
        data = file.readlines()
    return data

def process_data(data):
    even_numbers = []
    for line in data:
        number = int(line.strip())
        if number % 2 == 0:
            even_numbers.append(number)
    return even_numbers

def write_file(file_path, data):
    with open(file_path, 'w') as file:
        for number in data:
            file.write(f"{number}\n")

# Define file paths
input_file_path = '../data/gpsAll.csv'
output_file_path = '../data/gpsSelected.csv'

# Read, process, and write data
data = read_file(input_file_path)
even_numbers = process_data(data)
write_file(output_file_path, even_numbers)

print("Processing complete. Check the gpscleaned file for the results.")
