'''
You can save the list of valid elevations as a CSV file using Python's `csv` module. 
An example that demonstrates how to do this:
'''

import csv

# Function to check if an elevation is within the acceptable range
def check_elevation(elevation):
    return -149 < elevation < 4500

# Sample elevations to test
sample_elevations = [3000, 5000, -200, 4500, -100, 0, 4000]

# Create a new list to store valid elevations
valid_elevations = []

# Iterate over each elevation in the sample_elevations list
for elevation in sample_elevations:
    # Check if the current elevation is within the acceptable range
    if check_elevation(elevation):
        # If it is, add it to the valid_elevations list
        valid_elevations.append(elevation)

# Specify the filename
filename = "./data/valid_elevations.csv" #This will be saved in directory named data

# Write the valid elevations to a CSV file
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    # Write a header row if needed
    writer.writerow(["Elevation"])
    # Write the valid elevations
    for elevation in valid_elevations:
        writer.writerow([elevation])

print(f"Valid elevations have been saved to {filename}")
### Explanation:
##### Import the `csv` module: This module provides functionality to read from and write to CSV files.
##### Define the `check_elevation` function: This function checks if an elevation is within the specified range.
##### Create a list of sample elevations: These are the elevations we want to test.
##### Filter the valid elevations: Iterate through the sample elevations and add the valid ones to the `valid_elevations` list.
##### Specify the filename: Name the CSV file where the valid elevations will be saved.
##### Write to the CSV file: Open the file in write mode, create a CSV writer object, and write the valid elevations to the file. Optionally, a header row is added for clarity.

# This script will create a CSV file named `valid_elevations.csv` 
# containing the elevations that fall within the acceptable range.