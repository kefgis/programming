A =['Forest', 'Crop','Grass','Water']
# area of land cover
B=[120,452,222,245]
#Print the land cover and its area
c = 0
for D in A:
    print(D)