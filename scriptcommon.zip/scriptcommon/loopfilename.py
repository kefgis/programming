A = ['river','kebele','town']

F = 'C:/eth/'
# buffering distance
Di = 100
for i in A:
    inData = F + '/' + i + '.shp'
    print(inData)

    outData = F + '/' + i + 'buffer' + str(Di) + 'm.shp'
    print(outData)




    # the GIS command to buffer (after unit 6)
    
    
    
    F = 'C:/geodb2017kefs/scriptcommon/data'